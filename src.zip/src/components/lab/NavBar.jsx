import React from "react";
import { motion } from "framer-motion";

const NAV_ITEMS = [
  { label: "People", id: "people" },
  { label: "Projects", id: "projects" },
  { label: "Papers", id: "papers" },
  { label: "News", id: "news" },
  { label: "Funding", id: "funding" },
  { label: "Join Us", id: "contact" },
];

export default function NavBar() {
  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <motion.nav
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 left-0 right-0 z-50"
      style={{
        backgroundColor: 'rgba(24, 21, 16, 0.92)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(58, 50, 40, 0.5)',
      }}
    >
      <div className="max-w-5xl mx-auto px-6 py-2.5 flex items-center justify-between gap-6">
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex-shrink-0 flex items-center gap-2.5 transition-opacity hover:opacity-70"
        >
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69a06131335d4d0b4fc95ea9/9d54103d4_CEDAR_3_color.png"
            alt="CEDAR lab logo"
            className="h-9 w-9 object-contain"
          />
          <span className="text-lg font-light tracking-tight" style={{ color: '#F0EAE0' }}>
            The <span className="font-semibold" style={{ color: '#3D9E6B' }}>CEDAR</span> Lab
          </span>
        </button>

        <div className="hidden sm:flex items-center flex-wrap justify-end">
          {NAV_ITEMS.map((item, i) => (
            <span key={item.id} className="flex items-center">
              {i > 0 && (
                <span className="text-xs mx-2.5" style={{ color: '#3A3228' }}>|</span>
              )}
              <button
                onClick={() => scrollTo(item.id)}
                className="text-xs tracking-wide transition-colors"
                style={{ color: '#A09080' }}
                onMouseEnter={e => e.currentTarget.style.color = '#D9A578'}
                onMouseLeave={e => e.currentTarget.style.color = '#A09080'}
              >
                {item.label}
              </button>
            </span>
          ))}
        </div>
      </div>
    </motion.nav>
  );
}