import React from "react";

export default function Footer() {
  return (
    <footer className="py-16 px-6" style={{ backgroundColor: '#0D0C08' }}>
      <div className="max-w-4xl mx-auto text-center">
        <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69a06131335d4d0b4fc95ea9/9d54103d4_CEDAR_3_color.png"
          alt="CEDAR Lab Logo"
          className="w-16 h-16 mx-auto mb-5"
        />
        <p className="text-2xl font-light tracking-tight mb-2" style={{ color: '#F0EAE0' }}>
          The <span className="font-semibold" style={{ color: '#3D9E6B' }}>CEDAR</span> Lab
        </p>
        <p className="text-sm tracking-wide" style={{ color: '#A09080' }}>
          Thayer School of Engineering at Dartmouth
        </p>
        <div className="w-8 h-[1px] mx-auto my-6" style={{ background: '#2E2820' }} />
        <p className="text-xs" style={{ color: '#8A7E72' }}>
          Causality for Experimentation, Detection, and AI Recourse
        </p>
        
        {/* Dartmouth D-Pine Logo */}
        <div className="flex justify-center mt-10" style={{ padding: '20px 0' }}>
          <a href="https://engineering.dartmouth.edu/" target="_blank" rel="noopener noreferrer">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69a06131335d4d0b4fc95ea9/2fcff2481_D-Pine_Rev.png"
              alt="Dartmouth College"
              className="h-16 w-auto object-contain opacity-70 hover:opacity-90 transition-opacity"
            />
          </a>
        </div>
      </div>
    </footer>
  );
}